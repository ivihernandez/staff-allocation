'''
Created on Sep 23, 2012

@author: ivihernandez
'''
#standard imports
import random
#non standard imports
import SimPy.Simulation as simpy

#ivan's imports
serviceTime = 12

class Customer(simpy.Process):
    """ Customer arrives, looks around and leaves """
    def __init__(self,
                 name,
                 resources,
                 monitors,
                 times,
                 exitResource,
                 exitMonitor):
        simpy.Process.__init__(self)
        self.resources = resources
        self.monitors = monitors
        self.times = times
        self.exitResource = exitResource
        self.exitMonitor = exitMonitor
        self.name = name
    
    def visit(self):
        self.debug = False
        for i in self.visit_greeter():
            yield i
        
    
    def visit_greeter(self):       
        name = 'greeter'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        tib = 0.5#random.expovariate(1.0/self.times[name])
        #tib = random.expovariate(1.0/10) 
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
        p = random.random()
        if p < 0.5:
            #yield self.visit_screener()
            
            for i in self.visit_screener():
                yield i
            
        else:
            #yield self.visit_dispenser()
            
            for i in self.visit_dispenser():
                yield i
            
        
        
        
        
         
    def visit_screener(self):
        """
            After cleaning
            
            Aggregated:
            
            Lognormal with:
                logarithmic mean: -2.125
                logarithmic std dev: 0.428
            
            Separated:
            Medical Screening -> Gamma distribution with
                                 shape: 4.876
                                 rate: 32.55
            Ciprofloxacin Screening -> Gamma distribution with
                                 shape: 6.258
                                 rate: 47.165
            Doxycycline Screening -> Lognormal distribution with
                                logarithmic mean: -2.165
                                logarithmic std dev: 0.413
        """       
        name = 'screener'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        #tib = random.expovariate(1.0/self.times[name])   
        tib = random.lognormvariate(mu=-2.125, sigma=0.428)
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
        
        
        p = random.random()
        if p <= 0.5:
            #yield self.visit_medic()
            
            for i in self.visit_medic():
                yield i
            
        else:
            #yield self.visit_dispenser()
            
            for i in self.visit_dispenser():
                yield i
            
    
    def visit_dispenser(self):
        """
            Best fit obtained after cleaning the data:
            Weibull Distribution with:
                shape: 1
                scale: 0.311
        """       
        name = 'dispenser'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        #tib = random.expovariate(1.0/self.times[name])
        tib = random.weibullvariate(alpha=1, beta=0.311)   
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
        
        #yield self.visit_exit()
        
        for i in self.visit_exit():
            yield i
        
    
    def visit_medic(self):
        """
            Lognormal with :
            logarithmic mean: 1.024
            logarithmic std dev: 0.788
        """       
        name = 'medic'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        #tib = random.expovariate(1.0/self.times[name])
        tib = random.lognormvariate(mu=1.024, sigma=0.788)
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
    
        p = random.random()
        if p < 0.5:
            #yield self.visit_dispenser()
            
            for i in self.visit_dispenser():
                yield i
            
        else:
            #yield self.visit_exit()
            
            for i in self.visit_exit():
                yield i
            
        
    def visit_exit(self):       
        name = 'exit'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.exitResource
        wait = simpy.now() - arrive
        self.exitMonitor.observe(wait)
        tib = 0#random.expovariate(1.0/self.times[name])   
        yield simpy.hold,self,tib
        yield simpy.release, self, self.exitResource
    

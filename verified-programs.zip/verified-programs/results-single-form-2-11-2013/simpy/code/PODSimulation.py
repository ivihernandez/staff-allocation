'''
Created on Sep 24, 2012

@author: ivihernandez
'''
#standard imports
import random
from collections import defaultdict
#non standard imports
import SimPy.Simulation as simpy
import SimPy.SimPlot as simplot
import numpy
#ivan's imports

import Source



class PODSimulation:
    def __init__(self, capacities):
        self.maxTime = 1440# 24*60=1440 minutes
        self.maxNumber = 5000 #entities
        self.arrivalInterval = 10 #mean, minutes
        self.capacities = capacities
        #positions = [greeter, screener, dispenser, medic]
        self.resources = {} #resource name -> resource
        self.monitors = {} #resource name -> monitor
        self.times = {} #resource name -> avg. time
        
        ylab= 'Arrived'
        ########################
        name = 'greeter'
        n = 0
        self.resources[name] = simpy.Resource(capacity=capacities[n], 
                                             name=name,
                                             monitored=True)
        self.monitors[name] = simpy.Monitor(name=name, ylab=ylab)
        #self.times[name] = 10
        ########################
        name = 'screener'
        n = 1
        self.resources[name] = simpy.Resource(capacity=capacities[n], 
                                             name=name,
                                             monitored=True)
        self.monitors[name] = simpy.Monitor(name=name, ylab=ylab)
        #self.times[name] = 10
        ########################        
        name = 'dispenser'
        n = 2
        self.resources[name] = simpy.Resource(capacity=capacities[n], 
                                             name=name,
                                             monitored=True)        
        self.monitors[name] = simpy.Monitor(name=name, ylab=ylab)
        #self.times[name] = 10
        ########################
        name = 'medic'
        n = 3
        self.resources[name] = simpy.Resource(capacity=capacities[n], 
                                             name=name,
                                             monitored=True)
        self.monitors[name] = simpy.Monitor(name=name, ylab=ylab)
        #self.times[name] = 10
        
        
        ########################
        name = 'exit'
        self.exitResource = simpy.Resource(capacity=1,name=name)
        self.exitMonitor = simpy.Monitor(name=name, ylab=ylab)
        self.exitTime = 0
    def get_capacities(self):
        return self.capacities
    def model(self, seed):
        random.seed(seed)
        
        
        simpy.initialize()
        
        source = Source.Source('Source')
        simpy.activate(source, 
                       source.generate(number=self.maxNumber,
                                       interval=self.arrivalInterval,
                                       resources=self.resources,
                                       monitors=self.monitors,
                                       times=self.times,
                                       exitResource=self.exitResource,
                                       exitMonitor=self.exitMonitor
                                        ),
                      at=0.0
                    )
        simpy.simulate(until=self.maxTime)
        
        #return (monitorResource.count, monitorResource.mean())
    def print_stats(self, name):
        print "entities processed",self.monitors[name].count()
        value = 0
        try:
            value =  self.monitors[name].mean()
        except ZeroDivisionError:
            value = 0
        print "avg. waiting time",value
    def get_avg_waiting_times(self):
        """
            get avg. waiting time per service
        """
        sum = 0
        for key in self.monitors.keys():
            try:
                value = self.monitors[key].mean()
            except ZeroDivisionError:
                value = 0
            sum += value
            
        
        return sum
    def get_waiting_time(self, key):
        """
            @param key: name of the resource 
            (e.g. greeter, medic, screener, dispenser)
            return the avg. waiting time for a specific resource monitor 
        """
        return self.monitors[key].mean()
    def get_resource_count(self):
        sum = 0
        for key in self.resources.keys():
            value = self.resources[key].capacity
            sum += value
        return sum
    def get_processed_count(self):
        
        return self.exitMonitor.count()
    def plot_stats(self):
        plt = simplot.SimPlot()
        plt.plotStep(self.monitors['greeter'],color='blue')
        plt.plotStep(self.monitors['screener'],color='red')
        plt.plotStep(self.monitors['dispenser'],color='green')
        plt.plotStep(self.monitors['medic'],color='purple')
        plt.mainloop()
    def get_number_waiting(self, key):
        """
            Return the average number of people waiting for the resource
            named "key". This is a weighted average, weighted by
            the amount of time in which the queue had a given size.
            
            @param key: name of the queue 
        """
        monitor = self.resources[key].waitMon #list of [time, size]
        waiting = defaultdict(float)
        total = 0
        for i in range(len(monitor)):
            if i == 0:
                continue
            timeSpan = monitor[i][0] - monitor[i - 1][0]
            index = monitor[i - 1][1]
            waiting[index] += timeSpan
            total += timeSpan * index
        #include last state of the queue
        timeSpan = self.maxTime - monitor[len(monitor) - 1][0]
        index = monitor[len(monitor) - 1][1]
        waiting[index] += timeSpan
        total += timeSpan * index
        total = total / self.maxTime
        return total
    def get_utilization(self, key):
        """
            @param key: name of the queue
             
        """
        monitor = self.resources[key].waitMon #list of [time, size]
        waiting = defaultdict(float)
        total = 0
        for i in range(len(monitor)):
            if i == 0:
                continue
            index = monitor[i - 1][1]
            if index == 0:
                continue
            timeSpan = monitor[i][0] - monitor[i - 1][0]
            waiting[index] += timeSpan
            total += timeSpan 
        #include last state of the queue
        index = monitor[len(monitor) - 1][1]
        if index != 0:
            timeSpan = self.maxTime - monitor[len(monitor) - 1][0]
            waiting[index] += timeSpan
            total += timeSpan 
        total = total / self.maxTime
        return total
        
          

class ResultsAnalyzer:
    def __init__(self, simulations):
        """
            This function takes the average of multiple simulation 
            statistics and averages them in order to obtain a better
            estimate. The statistics analyzed are:
            1) Total Average waiting time
            2) Total Number of resources
            3) Total Number of entities processed
            4) Waiting times per queue
            5) Average number waiting per queue
            6) Utilization per resource
            7) Total Number Seized per resource
            
            
            @param simulations: list of objects of type PODSimulation
             
        """
        self.waiting = defaultdict(float)        #resource -> avg. waiting time
        self.number = defaultdict(float)         #resource -> avg. number waiting
        self.utilization = defaultdict(float)    #resource -> avg. utilization
        self.seized = defaultdict(float)         #resource -> avg. number seized
        self.avgTotalProcessed = 0       #total resources processed
        self.avgTotalWaitingTime = 0            #total avg. waiting time
        self.totalResources = 0       #total number of resources
        self.capacities = 0         #resources per queue
        
        self.capacities = simulations[0].get_capacities()
        self.totalResources = simulations[0].get_resource_count()
        self.n = len(simulations)
        self.maxTime = simulations[0].maxTime
        n = self.n
        
        for simul in simulations:
            
            self.avgTotalProcessed += simul.get_processed_count() / float(n)
            self.avgTotalWaitingTime += simul.get_avg_waiting_times() / float(n)
            for key in simul.monitors.keys():
                #waiting time
                try:
                    self.waiting[key] += simul.monitors[key].mean() / float(n)
                except ZeroDivisionError:
                    self.waiting[key] += 0
            for key in simul.resources.keys():
                #number waiting
                self.number[key] += simul.get_number_waiting(key) / float(n)#simul.resources[key].waitMon.mean() / float(n)
                #utilization
                self.utilization[key] += simul.get_utilization(key) /float(n)
                #number seized
                self.seized[key] += simul.monitors[key].count() / float(n)
    def get_total_resources(self):
        return self.totalResources
    def get_avg_total_waiting_time(self):
        return self.avgTotalWaitingTime
    def get_avg_total_processed(self):
        return self.avgTotalProcessed
    def get_total_time(self):
        return self.maxTime
    def show_results(self):
        print "simulation time", self.maxTime
        print "capacities", self.capacities
        print "total resources", self.totalResources
        print "total avg. waiting time (minutes)", self.avgTotalWaitingTime
        print "total avg. processed", self.avgTotalProcessed 
        print "Average waiting time (minutes)"
        for key in self.waiting.keys():
            print "\t", key, self.waiting[key]
        print "Average number waiting"
        for key in self.number.keys():
            print "\t", key, self.number[key]
        print "Average utilization"
        for key in self.utilization.keys():
            print "\t", key, self.utilization[key]
        print "Average number seized"
        for key in self.seized.keys():
            print "\t", key, self.seized[key]
"""
class Observer(simpy.Process):
    def __init__(self):
        simpy.Process.__init__(self)
    def observe(self):
        while True:
            yield hold,self,5
            q.append(len(counter.waitQ))
            t.append(simpy.now())        
"""             
if __name__ == '__main__':
    #greeter, screener, dispenser, medic
    print "program started"
    capacities = [1,1,1,1]
    seeds = [2308947, 
             982301, 
             329, 
             12389, 
             34324,
             45645,
             45456546,
             681683,
             7,
             543,
             3982473289,
             1321,
             798789,
             8809,
             35797,
             43,
             879,
             32432,
             78987,
             675489]
    #seeds = [123]
    simulations = []
    for seed in seeds:
        simul = PODSimulation(capacities)
        simul.model(seed)
        #print "average number waiting Dispenser", simul.get_number_waiting('dispenser')
        #print "utilization",simul.get_utilization("dispenser")
        simulations.append(simul)
    resultsAnalyzer = ResultsAnalyzer(simulations)
    resultsAnalyzer.show_results()
    print "program finished"
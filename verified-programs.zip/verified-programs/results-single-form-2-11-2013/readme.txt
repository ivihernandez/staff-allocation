Arena and SimPy obtain almost the exact same results.
TO DO:
1) change the splits form 0.5 in all decisions to real values
2) Add multiple forms per entity
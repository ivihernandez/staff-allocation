'''
Created on Sep 23, 2012

@author: ivihernandez
'''
#standard imports
import random
#non standard imports
import SimPy.Simulation as simpy

#ivan's imports



class Customer(simpy.Process):
    """ Customer arrives, looks around and leaves """
    def __init__(self,
                 name,
                 resources,
                 monitors,
                 times,
                 exitResource,
                 exitMonitor):
        simpy.Process.__init__(self)
        self.resources = resources
        self.monitors = monitors
        self.times = times
        self.exitResource = exitResource
        self.exitMonitor = exitMonitor
        self.name = name
        self.generate_forms()
        self.set_pre_screening_status()
    
    def set_pre_screening_status(self):
        """
            Determine if the person is pre-screened or not
        """
        p = random.random()
        if p <= 0.99:
            self.preScreened = True
        else:
            self.preScreened = False
    def generate_forms(self):
        """
            Determine number and type of forms that the person carries.
            Numbers based on the 
            NYC office of emergency preparedness and response
        """
        p = random.random()
        number = 0
        if (p >= 0) and (p <0.134):
            number = 1
        elif (p >= 0.134) and (p < 0.359):
            number = 2
        elif (p >= 0.359) and (p < 0.564):
            number = 3
        elif (p >= 0.564) and (p < 0.777):
            number = 4
        elif (p >= 0.777) and (p < 0.920):
            number = 5
        else:
            number = 6
        
        p = random.random()
        if (p >= 0) and (p < 0.88):
            formType = 'DOXYCYCLINE'
        elif (p >= 0.88) and (p < 0.99):
            formType = 'CIPROFLOXACIN'
        else:
            formType = 'MEDICAL'
        self.forms = formType * number
        self.number = number
        
    def visit(self):
        self.debug = False
        for i in self.visit_greeter():
            yield i
        
    
    def visit_greeter(self):       
        name = 'greeter'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        tib = 0.5#random.expovariate(1.0/self.times[name])
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
        p = random.random()
        if self.preScreened:
            for i in self.visit_dispenser():
                yield i
        else:
            for i in self.visit_screener():
                yield i
            
        
        
        
        
         
    def visit_screener(self):
        """
            After cleaning
            
            Aggregated:
            
            Lognormal with:
                logarithmic mean: -2.125
                logarithmic std dev: 0.428
            
            Separated:
            Medical Screening -> Gamma distribution with
                                 shape: 4.876
                                 rate: 32.55
            Ciprofloxacin Screening -> Gamma distribution with
                                 shape: 6.258
                                 rate: 47.165
            Doxycycline Screening -> Lognormal distribution with
                                logarithmic mean: -2.165
                                logarithmic std dev: 0.413
        """       
        name = 'screener'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        time = random.lognormvariate(mu=-2.125, sigma=0.428)
        tib = self.number * time
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
        
        
        if 'MEDIC' in self.forms:
            for i in self.visit_medic():
                yield i
        else:
            for i in self.visit_dispenser():
                yield i
            
    
    def visit_dispenser(self):
        """
            Best fit obtained after cleaning the data:
            Weibull Distribution with:
                shape: 1
                scale: 0.311
        """       
        name = 'dispenser'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        time = random.weibullvariate(alpha=1, beta=0.311)
        #print len(self.forms)
        tib = self.number * time
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
        
        for i in self.visit_exit():
            yield i
        
    
    def visit_medic(self):
        """
            Lognormal with :
            logarithmic mean: 1.024
            logarithmic std dev: 0.788
        """       
        name = 'medic'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.resources[name]
        wait = simpy.now() - arrive
        self.monitors[name].observe(wait)
        time = random.lognormvariate(mu=1.024, sigma=0.788) 
        tib = self.number * time 
        yield simpy.hold,self,tib
        yield simpy.release, self, self.resources[name]
    
        p = random.random()
        if p < 0.99:
            for i in self.visit_dispenser():
                yield i
        else:
            for i in self.visit_exit():
                yield i
            
        
    def visit_exit(self):       
        name = 'exit'
        if self.debug:
            print self.name, "at ",name, simpy.now()
        
        arrive = simpy.now()
        yield simpy.request, self, self.exitResource
        wait = simpy.now() - arrive
        self.exitMonitor.observe(wait)
        tib = 0#random.expovariate(1.0/self.times[name])   
        yield simpy.hold,self,tib
        yield simpy.release, self, self.exitResource
    
